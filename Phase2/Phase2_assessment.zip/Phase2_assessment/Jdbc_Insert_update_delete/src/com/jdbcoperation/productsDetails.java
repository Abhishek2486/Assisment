package com.jdbcoperation;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dbconnection.DBConnection;



/**
 * Servlet implementation class productsDetails
 */
@WebServlet("/jdbcoperation")
public class productsDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public productsDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dbcurl="jdbc:mysql://localhost:3306/ecommerce";
		String username="root";
		String password="ADMIN";
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		try {
			DBConnection dbConnection=new DBConnection(dbcurl, username, password);
			Connection connection=dbConnection.getconnection();
			Statement stmt= connection.createStatement();
			stmt.executeUpdate("insert into eproduct (Pname,Price) Values ('Lenovo',36000)");
			out.println("record inserted succsesfully"+"</br>");
			stmt.executeUpdate("update eproduct set Price= 20000 where Pname='Lenovo'");
			out.println("record updated succsesfully"+"</br>");
			stmt.executeUpdate("Delete from eproduct where Pname='lenovo'");
			out.println("record delete Succsesfully");
			stmt.close();
			out.println("</body></html>");
			dbConnection.closeConnection();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
