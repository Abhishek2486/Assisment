package com.hibernate.products;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Eproduct;
import com.util.HibernateUtilClass;

/**
 * Servlet implementation class AddProducts
 */
@WebServlet("/add-product")
public class AddProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddProducts() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("add-product.html").include(request, response);
	
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		String productName = request.getParameter("name");
		String productPrice = request.getParameter("price");

		SessionFactory sf = HibernateUtilClass.buildSessionFactory();

		Session session = sf.openSession();

		Transaction tx =  session.beginTransaction();


		Eproduct product = new Eproduct();
		product.setName(productName);
		product.setPrice(Double.parseDouble(productPrice));


		tx.commit();

		out.print("<h3> Product is created successfully ! <h3>");
		session.close();
	}

}
