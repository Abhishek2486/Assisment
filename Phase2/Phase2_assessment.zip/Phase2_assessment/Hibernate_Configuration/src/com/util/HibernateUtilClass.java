package com.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class HibernateUtilClass {
	public static SessionFactory buildSessionFactory(){
		SessionFactory sf= new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		return sf;
	}

}
