package com.Simplilearn.Jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Simplilearn.util.DBConnection;

/**
 * Servlet implementation class ListProducts
 */
@WebServlet("/listeproducts")
public class ListProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListProducts() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dbcurl="jdbc:mysql://localhost:3306/ecommerce";
		String username="root";
		String password="ADMIN";
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		try {
			DBConnection dbconnection = new DBConnection(dbcurl,username,password);

			Connection connection=dbconnection.getconnection();
			Statement statment=connection.createStatement();
			statment.executeUpdate("insert into eproduct(Pname,Price) values ('APPLE',50000)");
			ResultSet rslt=statment.executeQuery("select * from eproduct");
			while(rslt.next()) {
				String Product_name=rslt.getString("Pname");
				BigDecimal Product_Price=rslt.getBigDecimal("Price");
				out.println(Product_name+" "+Product_Price+"</br>");
			
			}
			statment.close();
			out.println("</body></html>");
			dbconnection.closeConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
