package com.simplilearn;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns="/s")
public class GenericServletEx extends GenericServlet{

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
    PrintWriter pr=res.getWriter();
    pr.append("<html><body>");
    String name=req.getParameter("name");
    pr.append("Hi  i am using Servlet");
    pr.append("with the name "+name);
    pr.append("</body></html>");
		
	}

}
