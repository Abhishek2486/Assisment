package com.Spring.Kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringKafkaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
