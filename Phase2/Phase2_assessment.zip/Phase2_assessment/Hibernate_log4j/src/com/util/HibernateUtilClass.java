package com.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.entity.Eproduct;

public class HibernateUtilClass {
public static SessionFactory buildSessionFactory() {
	SessionFactory sf= new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Eproduct.class).buildSessionFactory();
	return sf;

	
}
}
