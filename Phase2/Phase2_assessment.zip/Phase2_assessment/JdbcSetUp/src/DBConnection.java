import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	private Connection connection;
	public DBConnection(String dbcurl,String username,String password) throws ClassNotFoundException, SQLException{
	
		Class.forName("com.jdbc.mysql.Driver");
		
		connection =DriverManager.getConnection(dbcurl,username,password);
		
	}
	public Connection getconnection() {
		return connection;
		
		}
	 public void closeConnection() throws SQLException{
			if(connection !=null)
				connection.close();
	}
}
