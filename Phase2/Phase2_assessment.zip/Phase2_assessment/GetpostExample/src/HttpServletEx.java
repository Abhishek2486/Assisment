import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns ="/getpostexample")
public class HttpServletEx extends HttpServlet {

  public void doGet(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException{
    	PrintWriter prt =resp.getWriter();
    	prt.append("<html><body>");
    	String name=req.getParameter("name");
    	prt.append("HI THIS "+name);
    	prt.append("this is Servlet");
    	prt.append("GET EXAMPLE");
    	prt.append("</body></html>");
    	
    }
   public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException{
      	PrintWriter prt =resp.getWriter();
    	prt.append("<html><body>");
    	String name=req.getParameter("name");
     	prt.append("HI THIS IS "+name);
    	prt.append("this is Servlet");
    	prt.append(" POST EXAMPLE");
    	prt.append("</body></html>");
    }
}
