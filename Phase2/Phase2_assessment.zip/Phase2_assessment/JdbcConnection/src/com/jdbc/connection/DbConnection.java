package com.jdbc.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	private Connection connection;
	public  DbConnection(String dbcurl,String username,String password) throws ClassNotFoundException, SQLException{
	
		Class.forName("com.jdbc.cj.mysql.Driver");
		
		connection =DriverManager.getConnection(dbcurl,username,password);
		System.out.println("connected");
		
	}
	public Connection getconnection() {
		return connection;
		
		}
	 public void closeConnection() throws SQLException{
			if(connection !=null)
				connection.close();
	}
}
