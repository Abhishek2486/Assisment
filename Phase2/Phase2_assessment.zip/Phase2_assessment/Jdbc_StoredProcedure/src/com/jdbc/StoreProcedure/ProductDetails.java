package com.jdbc.StoreProcedure;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DBconnection.DBConnection;

/**
 * Servlet implementation class ProductDetails
 */
@WebServlet("/productlist")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="jdbc:mysql://localhost:3306/ecommerce";
		String username="root";
		String password="ADMIN";
      PrintWriter out =response.getWriter();
      out.println("<html><body>");
      try {
		DBConnection dbconnection =new DBConnection(url, username, password);
		Connection connection=dbconnection.getconnection();
		PreparedStatement stmt =connection.prepareStatement("insert into eproduct (Pname,Price) Values (?,?)");
		stmt.setString(1, "ASUS");
		stmt.setBigDecimal(2,new BigDecimal(43000));
		stmt.executeUpdate();
        out.println("Stored procedure has been executed.<Br>");
		stmt.executeQuery("select * from eproduct");
		stmt.close();
		out.println("</body><html>");
		dbconnection.closeConnection();
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 
      
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
