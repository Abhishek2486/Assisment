package com.Spring.eventhandling.event.listners;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.Spring.eventhandling.events.NewsEvent;

@Component
public class NewsListner {

	@EventListener
	public void listenNewsEvent(NewsEvent ne) {
		System.out.println("News Event published ::");
	}
}
