package com.Spring.eventhandling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringEventHandlingApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ac=SpringApplication.run(SpringEventHandlingApplication.class, args);
	
	}

}
