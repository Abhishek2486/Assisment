package com.operation;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class DatabaseOp
 */
@WebServlet("/CSDoperation")
public class DatabaseOp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DatabaseOp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dbcurl="jdbc:mysql://localhost:3306/ecommerce";
		String username="root";
		String password="ADMIN";
		PrintWriter out =response.getWriter();
		out.println("<html><body>");
		try {
			DBConnection dbconnection=new DBConnection(dbcurl, username, password);
			Connection connection =dbconnection.getconnection();
			Statement stmt =connection.createStatement();
            stmt.executeUpdate("create database MySqlDatabase");
            out.println("Created database:MySqlDatabase<br>");
            stmt.executeUpdate("use MySqlDatabase");
            out.println("Selected database: MySqlDatabase<br>");
      stmt.executeUpdate("drop database MySqlDatabase");
            stmt.close();
         out.println("Dropped database: MySqlDatabase<br>");
            stmt.close();
            out.println ("</body></html>");
            dbconnection.closeConnection();

			} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
