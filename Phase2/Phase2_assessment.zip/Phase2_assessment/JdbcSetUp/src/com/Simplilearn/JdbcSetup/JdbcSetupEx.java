package com.Simplilearn.JdbcSetup;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class JdbcSetupEx
 */
@WebServlet("/list")
public class JdbcSetupEx extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public JdbcSetupEx() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dbcurl="jdbc:mysql://localhost:3306/ecommerce";
		String username="root";
		String password="ADMIN";
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		try {
			DBConnection dbconnection = new DBConnection(dbcurl,username,password);

			Connection connection=dbconnection.getconnection();
			out.println("DB Connection initialized.<br>");
			out.println("</body></html>");
			dbconnection.closeConnection();
			out.println("DB Connection closed.<br>");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
