package com.Spring.SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestfulWithSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
