package com.Simplilearn.Spring.model;

public class EProduct {
	private 
}
